package sugo

import (
	"github.com/sunamo/sugo"
)

// Int convert []int to []interface{}
func Int(a []int) []interface{} {
	l := len(a)
	arr := make([]interface{}, l)
	for i := 0; i < l; i++ {
		arr[i] = a[i]
	}
	return arr
}

// Int64 convert []int64 to []interface{}
func Int64(a []int64) []interface{} {
	l := len(a)
	arr := make([]interface{}, l)
	for i := 0; i < l; i++ {
		arr[i] = a[i]
	}
	return arr
}

// Contains whether A1 contains A1. Cant use []inteface for []int64 https://golang.org/doc/faq#convert_slice_of_interface, https://github.com/golang/go/issues/6804
func Contains(s []interface{}, e interface{}) bool {
	for _, a := range s {
		if sugo.ToStr(a) == sugo.ToStr(e) {
			return true
		}
	}
	return false
}
