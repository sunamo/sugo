package sugo

import "fmt"

// During problem with import packages simply entry really not exists. popup will show paths

// Exc print error if exists
func Exc(e error) {
	if e != nil {
		fmt.Println((e))
	}
}
