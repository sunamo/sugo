package sugo

import (
	"fmt"
	"github.com/sunamo/sugo"
	"strings"
)

//Join strings
func Join(sep string, a ...interface{}) string {
	fs := make([]string, len(a))

	for i := 0; i < len(a); i++ {
		o := a[i]
		str := ToStr(o)
		fs[i] = str
	}
	return strings.Join(fs, sep)
}

func ToStr(a interface{}) string {
	return fmt.Sprintf("%v", a)
}
